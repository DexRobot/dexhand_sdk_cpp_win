﻿#include"Dexterous_hands.h"
#include <iostream>

int main()
{
    Dexterous_hands Hand;
    unsigned char version[5];
    Hand.start();
    hand.get_sdk_version(FingerID::RIGHT_THUMB, Channel::CAN0, version);
    for (size_t i = 0; i < 4; i++) {
        std::cout << (int)version[i] << " ";
    }
    Hand.Degree_Control_mode(FingerID::LEFT_INDEX, Channel::CAN0, JointMotor::ALL, 500, 500)；
    Hand.stop();
    return 0;
}

