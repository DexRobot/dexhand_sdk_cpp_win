#pragma once
#include"Protocols.h"

struct FilterAttributes
{
	std::string ENB = "enabled";
	std::string STA = "start";
	std::string END = "end";
};

struct FilterConfig
{
	bool enabled;
	std::string start;
	std::string end;
};

struct ChannelProperties
{
	struct Attributes
	{
		std::string IDX = "id";
		std::string FMT = "format";
		std::string ENB = "enabled";
		std::string MRG = "merge";
		std::string RST = "resistance";
	};

	std::string CLK = "clock-rate";
	std::string ART = "abit-rate";
	std::string DRT = "dbit-rate";
	std::string FLT = "filter";
};

struct ChannelConfig
{
	unsigned int id;
	std::byte format; // 0 for CAN, 1 for CANFD
	bool enabled;
	bool resistance;
	bool merge;
	std::string clockRate;
	std::string abitRate;
	std::string dbitRate;
	FilterConfig filter;
};

enum CanProvider
{
	UNKNOWN = 0,
	ZLG,
};

class CANConfig {
public:
	CanProvider provider;
	ZCAN_DeviceType deviceType;
	unsigned int deviceIndex;
	std::string deviceName;
	std::vector<ChannelConfig> channels;  // Channels will be used.

	CANConfig();

	CANConfig(ZCAN_DeviceType deviceType);

	CANConfig& operator=(const CANConfig& other);

	bool configured();

	void addChannel(unsigned int channelIdx, FilterConfig filter,
		std::string abRate = "1000000", std::string dbRate = "2000000",
		std::string baudRate = "60000000");

private:

};



class ZCanHandMessage  {
	
public:
	ZCanHandMessage();
	ZCanHandMessage(ZCAN_DeviceType Type);

	void Dispose();
   
	bool stop();

	bool start();

	~ZCanHandMessage();

	ZCanHandMessage& operator=(const ZCanHandMessage& other)=delete;

	ZCanHandMessage(const ZCanHandMessage&) = delete;

	ZCanHandMessage(const ZCanHandMessage&&) = delete;

	bool send(FingerMessage_CANFD message, unsigned char channel, int waitTime = 10, bool withErrorMsg = false);

	bool Recive( ZCAN_ReceiveFD_Data* ptr, unsigned char channel, int waitTime = 10, bool withErrorMsg = false);

	void*  hDevice;

	void* chHandle_0;

	void* chHandle_1;
	unsigned int MyIndexId;
	CANConfig _config;

	std::unordered_map<unsigned int, void*> channelHandles;
	bool instanced;
	bool started;
	bool initDevice();
};



