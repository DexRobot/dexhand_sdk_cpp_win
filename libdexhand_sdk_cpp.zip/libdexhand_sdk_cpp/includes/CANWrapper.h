#pragma once
#include"Protocols.h"

struct FilterConfig
{
	bool enabled;
	std::string start;
	std::string end;
};

struct ChannelProperties
{
	struct Attributes
	{
		std::string IDX = "id";
		std::string FMT = "format";
		std::string ENB = "enabled";
		std::string MRG = "merge";
		std::string RST = "resistance";
	};

	std::string CLK = "clock-rate";
	std::string ART = "abit-rate";
	std::string DRT = "dbit-rate";
	std::string FLT = "filter";
};

struct ChannelConfig
{
	unsigned int id;
	std::byte format; // 0 for CAN, 1 for CANFD
	bool enabled;
	bool resistance;
	bool merge;
	std::string clockRate;
	std::string abitRate;
	std::string dbitRate;
	FilterConfig filter;
};

enum CanProvider
{
	UNKNOWN = 0,
	ZLG,
};


class ZCanHandMessage  {
	
public:
	ZCanHandMessage();
	ZCanHandMessage(ZCAN_DeviceType Type);

	void Dispose();
   
	bool stop();

	bool start();

	~ZCanHandMessage();

	ZCanHandMessage& operator=(const ZCanHandMessage& other)=delete;

	ZCanHandMessage(const ZCanHandMessage&) = delete;

	ZCanHandMessage(const ZCanHandMessage&&) = delete;

	bool send(FingerMessage_CANFD message, unsigned char channel, int waitTime = 10, bool withErrorMsg = false);

	bool Recive( ZCAN_ReceiveFD_Data* ptr, unsigned char channel, int waitTime = 10, bool withErrorMsg = false);

	void*  hDevice;

	void* chHandle_0;

	void* chHandle_1;

	bool instanced;
	bool started;
	bool initDevice();
};



