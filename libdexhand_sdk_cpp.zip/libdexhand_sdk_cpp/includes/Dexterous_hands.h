#pragma once
#include"CANWrapper.h"

#ifdef DEXTEROUS_HANDS_EXPORTS
#define DEXTEROUS_HANDS_API __declspec(dllexport)
#else
#define DEXTEROUS_HANDS_API __declspec(dllimport)
#endif

enum class Channel {
    CAN0=0,
    CAN1=1
};

enum class ERROR_CODE {
    ERR_SUCC,               //�ɹ�
    ERR_INVALID_HANDLER,    //��Ч�ľ��
    ERR_INVALID_PARAMETER,  //��Ч�Ĳ���
    ERR_COMMUNICATION_ERR,  //ͨ�Ŵ���
    ERR_KINE_INVERSE_ERR,   //���ʧ��
    ERR_EMERGENCY_PRESSED,  //��ͣ��û���ɿ�
    ERR_NOT_POWERED,        //������δ�ϵ�
    ERR_NOT_ENABLED,        //������δʹ��
    ERR_PROGRAM_IS_RUNNING, //������������
    ERR_MOTION_ABNORMAL,    //�˶������з����쳣
    ERR_VALUE_OVERSIZE,     //Ԥ���ڴ治��
    OPEN_CAN_FAILED,         //�����豸ʧ��
    CLOSE_CAN_FAILED        //�ر��豸ʧ��
};

class Dexterous_hands
{
public:
    DEXTEROUS_HANDS_API Dexterous_hands();
    DEXTEROUS_HANDS_API void start();
    DEXTEROUS_HANDS_API void stop();
    DEXTEROUS_HANDS_API void get_sdk_version(FingerID id, Channel channel, unsigned char* version);
    DEXTEROUS_HANDS_API ErrorMessageRx Unable_Control_mode(FingerID fingerId, Channel channel, JointMotor motor);
    DEXTEROUS_HANDS_API ErrorMessageRx Degree_Control_mode(FingerID fingerId, Channel channel, JointMotor motor, unsigned short proximal, unsigned short distal);
    DEXTEROUS_HANDS_API ErrorMessageRx Hall_Control_mode(FingerID fingerId, Channel channel, JointMotor motor, unsigned short proximal, unsigned short distal);
    DEXTEROUS_HANDS_API ErrorMessageRx LimitHall_Control_mode(FingerID fingerId, Channel channel, JointMotor motor, short proximal, short distal);
    DEXTEROUS_HANDS_API void Open_Status_Feedback(FingerID fingerId, Channel channel, unsigned char Feedback_methods, unsigned char Feedback_cycles);
    DEXTEROUS_HANDS_API ZCAN_ReceiveFD_Data Clear_Error(Channel channel, FingerID fingerId);
    DEXTEROUS_HANDS_API FingerRxStatus Get_status_data(FingerID fingerId, Channel channel);
    DEXTEROUS_HANDS_API void Close_Status_Feedback(FingerID fingerId, Channel channel, unsigned char Feedback_methods, unsigned char Feedback_cycles);
    DEXTEROUS_HANDS_API ~Dexterous_hands();
protected:
    class imp ;
    std::unique_ptr<imp> _pImpl;
};

