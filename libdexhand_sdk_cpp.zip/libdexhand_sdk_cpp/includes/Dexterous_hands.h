#pragma once
#include"CANWrapper.h"

#ifdef DEXTEROUS_HANDS_EXPORTS
#define DEXTEROUS_HANDS_API __declspec(dllexport)
#else
#define DEXTEROUS_HANDS_API __declspec(dllimport)
#endif

enum class Channel {
    CAN0=0,
    CAN1=1
};
/*
* ö����
   jointMotor:: 
   DIST = 0x01,//��������
   PROX = 0x02,//Զ������
   ALL = 0x03//��ʹ��

   FingerRxStatus�ṹ�����ͣ�
     unsigned int   channelId;
     unsigned int   fingerId;
     int    current1;
     int16_t  position1;
     int    speed1;
     int    current2;
     int16_t  position2;
     int    speed2;
     float  degree1;  // value of degree sensor 1
     float  degree2;  // value of degree sensor 2
     float nForce;  // value of normal force on pressure sensor
     int    nForceDelta;  // delta of normal force on pressure sensor
     float tForce;  // value of tangencial force on pressure sensor
     int    tForceDelta;  // delta of tangencial force on pressure sensor
     int    tForceAngle;  // degree of tangencial force on pressure sensor
     int    approaching;
     int    temperature;
     int    adc1;
     int    adc2;
     unsigned long  timestamp;

*/

enum class ERROR_CODE {
    ERR_SUCC,               //�ɹ�
    ERR_INVALID_HANDLER,    //��Ч�ľ��
    ERR_INVALID_PARAMETER,  //��Ч�Ĳ���
    ERR_COMMUNICATION_ERR,  //ͨ�Ŵ���
    ERR_KINE_INVERSE_ERR,   //���ʧ��
    ERR_EMERGENCY_PRESSED,  //��ͣ��û���ɿ�
    ERR_NOT_POWERED,        //������δ�ϵ�
    ERR_NOT_ENABLED,        //������δʹ��
    ERR_PROGRAM_IS_RUNNING, //������������
    ERR_CANNOT_OPEN_FILE,   //���ļ�ʧ��
    ERR_MOTION_ABNORMAL,    //�˶������з����쳣
    ERR_VALUE_OVERSIZE,     //Ԥ���ڴ治��
    OPEN_CAN_FAILED,         //�����豸ʧ��
    CLOSE_CAN_FAILED        //�ر��豸ʧ��
};

class Dexterous_hands
{
public:
    DEXTEROUS_HANDS_API Dexterous_hands();
    DEXTEROUS_HANDS_API void start();
    DEXTEROUS_HANDS_API void stop();
    DEXTEROUS_HANDS_API void get_sdk_version(FingerID id, Channel channel, unsigned char* version);
    DEXTEROUS_HANDS_API void Unable_Control_mode(FingerID fingerId, Channel channel, JointMotor motor);
    DEXTEROUS_HANDS_API void Degree_Control_mode(FingerID fingerId, Channel channel, JointMotor motor, unsigned short proximal, unsigned short distal);
    DEXTEROUS_HANDS_API void Hall_Control_mode(FingerID fingerId, Channel channel, JointMotor motor, unsigned short proximal, unsigned short distal);
    DEXTEROUS_HANDS_API void LimitHall_Control_mode(FingerID fingerId, Channel channel, JointMotor motor, short proximal, short distal);
    DEXTEROUS_HANDS_API void Open_Status_Feedback(FingerID fingerId, Channel channel, unsigned char Feedback_methods, unsigned char Feedback_cycles);
    DEXTEROUS_HANDS_API void Clear_Error(Channel channel, FingerID fingerId);
    DEXTEROUS_HANDS_API FingerRxStatus Get_status_data(FingerID fingerId, Channel channel);
    DEXTEROUS_HANDS_API void Close_Status_Feedback(FingerID fingerId, Channel channel, unsigned char Feedback_methods, unsigned char Feedback_cycles);
    DEXTEROUS_HANDS_API ~Dexterous_hands();
protected:
    class imp ;
    std::unique_ptr<imp> _pImpl;
};

