#pragma once
#include<Windows.h>
#pragma comment(lib,"user32.lib")


void SendMotionStopMessage(HWND hwnd, int wParam, Protocols_ActionPerformance& lParam) {
    SendMessage(hwnd, WM_MOTION_STOP, (WPARAM)wParam, (LPARAM)&lParam);
}
