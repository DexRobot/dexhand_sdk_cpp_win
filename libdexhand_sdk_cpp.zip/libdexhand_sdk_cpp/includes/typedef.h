#pragma once

typedef unsigned char      BYTE;
typedef unsigned int       UINT;
typedef unsigned long      ULONG;
typedef unsigned long long UINT64;
typedef unsigned short     USHORT;
typedef unsigned char      UCHAR;


